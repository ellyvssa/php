<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "sistem_dm";
$link = mysqli_connect ($dbhost, $dbuser,$dbpass,$dbname);

//check if connection fail
if($link){
    die ("connection with database is fail: ".mysqli_connect_errno().
    "-" .mysqli_connect_error());
}
?>