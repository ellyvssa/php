<?php
if (isset($_GET["order"])){
    $order = $_GET ["order"]; }
if (isset($_POST["submit"]))
{
    $userID = htmlentities(strip_tags(trim($_POST["userID"])));
    $password = htmlentities(strip_tags(trim($_POST["password"])));
    $order_error ="";
    if (empty($userID)){
        $order_error = "Username belum diisi <br>";
    }
    if (empty($password)){
        $order_error = "Password belum diisi <br>";
    } include ("dbconnect.php");
    $userID = mysqli_real_escape_string ($link,$username);
    $password = mysqli_real_escape_string ($link,$password);
    $password_sha1 =sha1($password);
    $query = "SELECT * FROM logmasuk WHERE username = '$userID' AND password = '$password_sha1'";
    $result = mysqli_query ($link,$query);
    if (mysqli_num_rows($result) == 0){
        $order_error .= "Username dan/atau password tidak sesuai";
    }
    mysqli_free_result($result);
    mysqli_close ($link);
    if ($order_error === "");
    session_start();
    $_SESSION["nama"] = $userID;
    header ("Location: inform.php");    
}

else {
    $order_error = "";
    $userID = "";
    $password = "";

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

<?php
if (isset($order)){
    echo "<div class=\"order\>$order<div>";
}
if ($order_error !==""){
    echo "<div class =\error\">$order_error</div>";
}
?>
    <div class="header">
        <div class="form-box">
            <div class="button-box">
                <div id="btn"></div>
                <button type="buttton" class="toggle-btn" onclick="Login()">Log In</button>
                <button type="buttton" class="toggle-btn" onclick="Register()">Register</button>
            </div>
          <div class="logo">
        <img src="jata-ilp.png">  
    </div>
     <form id="login" class="input-group" action="inform.php">
        <input type="text" class="input-field" placeholder="User ID" required>
        <input type="password" class="input-field" placeholder="Enter Password" required>
        <input type="checkbox" class="check-box"><span>Remember Password</span>
        <button type="submit" class="submit-btn1">Log In</button>
</form>

<?php
include ('dbconnect.php');
if (isset($_POST['userID'])){
    $email = $_POST['email'];
    $userID = $_POST['userID'];
    $password = $_POST['password'];
    $sql = "INSERT INTO logmasuk (email, userID, password)
    VALUES ('$email','$userID','$password')";
    $samb =  mysqli_connect ($dbhost, $dbuser, $dbpass, $dbname);
    $hasil = mysqli_query ($samb, $sql);
    if ($hasil){
    echo "<script>alert ('berjaya masuk');
    window.location='inform.php</script>";}
}
?>
    <form id="register" class="input-group" action="login.php">
        <input name="email" type="text" class="input-field" placeholder="Email ID" required>
        <input name="userID" type ="text" class="input-field" placeholder="Create Your ID" required>
        <input name="password" type="password" class="input-field" placeholder="Enter Password" required>
        <!-- <div class="dropdown">
          <button class="dropbtn">Kategori</button>
          <div class="dropdown-content">
        <a href="#">Pekerja</a>
        <a href="#">Pelajar</a>
        </div> -->  
        <input type="checkbox" class="check-box"><span>I agree to the terms & conditions</span>

   
    </form>

        </div>
    </div>

    <script>
        var x= document.getElementById("login");
        var y= document.getElementById("register");
        var z= document.getElementById("btn");

        function Register() {
            
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";
        }
        function Login() {
            
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0";
        }



    </script>

    
</body>
</html>