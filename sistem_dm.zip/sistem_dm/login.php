<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <div class="header">
        <div class="form-box">
            <div class="button-box">
                <div id="btn"></div>
                <button type="buttton" class="toggle-btn" onclick="Login()">Log In</button>
                <button type="buttton" class="toggle-btn" onclick="Register()">Register</button>
            </div>
          <div class="logo">
        <img src="jata-ilp.png">  
    </div>
     <form id="login" class="input-group">
        <input type="text" class="input-field" placeholder="User ID" required>
        <input type="password" class="input-field" placeholder="Enter Password" required>
        <input type="checkbox" class="check-box"><span>Remember Password</span>
        <button type="submit" class="submit-btn1">Log In</button>
</form>
    <form id="register" class="input-group">
        <input type="text" class="input-field" placeholder="Email ID" required>
        <input type="text" class="input-field" placeholder="Create Your ID" required>
        <input type="password" class="input-field" placeholder="Enter Password" required>
        <!-- <div class="dropdown">
          <button class="dropbtn">Kategori</button>
          <div class="dropdown-content">
        <a href="#">Pekerja</a>
        <a href="#">Pelajar</a>
        </div> -->  
        <input type="checkbox" class="check-box"><span>I agree to the terms & conditions</span>
        <button type="submit" class="submit-btn2">Register</button>
        
      
        
   
    </form>

        </div>
    </div>

    <script>
        var x= document.getElementById("login");
        var y= document.getElementById("register");
        var z= document.getElementById("btn");

        function Register() {
            
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";
        }
        function Login() {
            
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0";
        }



    </script>

    
</body>
</html>