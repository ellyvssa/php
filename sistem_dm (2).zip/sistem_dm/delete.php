<?php
session_start();
if (!isset($_SESSION["nama"])){
    header("Location: login.php");
}
$summary = $_GET['summary'];
include ('dbconnect.php');
$query = "DELETE FROM report WHERE summary = '$summary' ";

if (mysqli_query($link, $query)){
    header (location:"login.php");
}else{
    echo "ERROR, data gagal dihapus". mysqli_error($link);

}
mysqli_close($link);
?>